<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inscription</title>
</head>

<body>

    <form action="./inscriptionReussi.php" method="post">

        <label for="name">Entrez votre nom&nbsp;:</label>
        <input type="text" name="user_name" id="name">

        <label for="">Entrez votre adresse mail&nbsp;:</label>
        <input type="email" name="user_email" id="email">

        <label for="">Entrez votre mot de passe&nbsp;:</label>
        <input type="password" name="user_password" id="password">


        <label for="pfp">Entrez l'url de votre image de profil&nbsp;:</label>
        <input type="url" name="user_img" id="pfp">

        <input type="submit" value="S'inscrire">

    </form>


</body>

</html>


<?php


    if () {
        # code...
    }



?>